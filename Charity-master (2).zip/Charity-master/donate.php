    <!DOCTYPE html>
    <html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="Colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>STEL initiatives</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
            <!--
            CSS
            ============================================= -->
            <link rel="stylesheet" href="css/linearicons.css">=
            <link rel="stylesheet" href="css/font-awesome.min.css">
            <link rel="stylesheet" href="css/magnific-popup.css">
            <link rel="stylesheet" href="css/nice-select.css">
            <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
            <link rel="stylesheet" href="css/bootstrap.css">
            <link rel="stylesheet" href="css/main.css">
        </head>
        <body>

            <!-- Start Header Area -->
            <header class="default-header">
                <div class="container">
                    <div class="header-wrap">
                        <div class="header-top d-flex justify-content-between align-items-center">
                            <div class="logo">
                                <a href="#home"><img src="img/logoss.png" alt=""></a>
                            </div>
                            <div class="main-menubar d-flex align-items-center">
                                <nav class="hide">
                                    <a href="#home">Home</a>
                                    <a href="#project">Visit Makeup Store</a>
                                    <a href="#project">Projects</a>
                                    <a href="#about">About</a>
                                    <a href="donate">Donate</a>
                                </nav>
                                <div class="menu-bar"><span class="lnr lnr-menu"></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- End Header Area -->

            <!-- start banner Area -->
            

            <!-- Start donate Area -->
            <section class="donate-area relative section-gap" id="donate">
                <div class="overlay overlay-bg"></div>
                <div class="container">
                    <div class="row d-flex justify-content-end">
                        <div class="col-lg-6 col-sm-12 pb-80 header-text">
                            <h1>Donate Now</h1>
                            <p>
                                Give and it shall be given unto you
                            </p>
                        </div>
                    </div>
                    <div class="row d-flex justify-content-center">
                        <div class="col-lg-6 contact-left">
                            <div class="single-info">
                                <h4>Divided Evenly</h4>
                                <p>
                                    Donate now and never lack as a giver
                                </p>
                            </div>
                            <div class="single-info">
                                <h4>Transperancy All the Way</h4>
                                <p>
                                   Put a smile in the world of cancer patient today
                                </p>
                            </div>
                            <div class="single-info">
                                <h4>Trustworthy</h4>
                                <p>
                                  We oath to provide maximum efficiency to them
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-6 contact-right">
                            <form class="booking-form" id="paymentForm">
                                    <div class="row">
                                        <div class="col-lg-12 d-flex flex-column">
                                            <select name="type" class="app-select form-control" required>
                                                <option data-display="Project you want to donate">Project you want to donate</option>
                                                <option value="1">Awele Royal Home Project</option>
                                                <option value="2">Help the Needy Project</option>
                                                <option value="3">Heal the Sick Project</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-6 d-flex flex-column">
                                            <input id="first-name" placeholder="Enter your name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your name'" class="form-control mt-20" required="" type="text" required>
                                        </div>
                                        <div class="col-lg-6 d-flex flex-column">
                                            <input id="email-address" placeholder="Enter email address" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'" class="form-control mt-20" required="" type="email">
                                        </div>
                                        <div class="col-lg-12 d-flex flex-column">
                                            <input id="amount" placeholder="Donation amount" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Donation amount (USD)'" class="form-control mt-20" required="" type="number" min="1000">

                                            <textarea class="form-control mt-20" name="message" placeholder="Messege" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Messege'" required=""></textarea>
                                        </div>

                                        <div class="col-lg-12 d-flex justify-content-end send-btn">
                                            <p><a onclick="payWithPaystack()"><button class="btn btn-primary btn-lg">Donate Now</button></a></p>
                                        </div>

                                        <div class="alert-msg"></div>
                                    </div>
                            </form>
                            
                            <p class="payment-method">
                                We Accept :   <img src="img/payment.png" alt="">
                            </p>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End donate Area -->


            <!-- start footer Area -->
            <footer class="footer-area section-gap">
                <div class="container">
                    <div class="row d-flex flex-column justify-content-center">
                        <ul class="footer-menu">
                            <li><a href="#home">Home</a></li>
                            <li><a href="#project">Projects</a></li>
                            <li><a href="#about">About</a></li>
                            <li><a href="donate">Donate</a></li>
                        </ul>
                        <div class="footer-social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-dribbble"></i></a>
                            <a href="#"><i class="fa fa-behance"></i></a>
                        </div>
                        <p class="footer-text m-0">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Jcode Tech Center</a>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </footer>
            <!-- End footer Area -->

            <script src="js/vendor/jquery-2.2.4.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
            <script src="js/vendor/bootstrap.min.js"></script>
            <script src="js/jquery.ajaxchimp.min.js"></script>
            <script src="js/jquery.nice-select.min.js"></script>
            <script src="js/jquery.sticky.js"></script>
            <script src="js/parallax.min.js"></script>
            <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
            <script src="js/jquery.magnific-popup.min.js"></script>
            <script src="js/main.js"></script>
        </body>
    </html>

<?php


// Function to calculate the subtotal





// List of all countries
$countries = [
    "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", 
    "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", 
    "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", 
    "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic", "Chad", 
    "Chile", "China", "Colombia", "Comoros", "Congo, Democratic Republic of the", "Congo, Republic of the", 
    "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", 
    "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", 
    "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada", 
    "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary", "Iceland", "India", 
    "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", 
    "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", 
    "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", 
    "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", 
    "Monaco", "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", 
    "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Macedonia", "Norway", "Oman", "Pakistan", "Palau", 
    "Palestine", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", 
    "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", 
    "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", 
    "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "Spain", "Sri Lanka", 
    "Sudan", "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", 
    "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", 
    "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", 
    "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"
];

?>
<!-- END nav -->

<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
    <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
                <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home</a></span> <span>Checkout</span></p>
                <h1 class="mb-0 bread">Checkout</h1>
            </div>
        </div>
    </div>
</div>

<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-10 ftco-animate">
                <form id="paymentForm">
  <div class="form-group">
    <label for="email">Email Address</label>
    <input type="email" id="email-address" required class="form-control" />
  </div>
  <div class="form-group">
    <label for="amount">Amount</label>
    <input type="number" id="amount" required class="form-control" min="1000" value="" />
  </div>
  <div class="form-group">
    <label for="first-name">First Name</label>
    <input type="text" id="first-name" class="form-control" />
  </div>
  <div class="form-group">
    <label for="last-name">Last Name</label>
    <input type="text" id="last-name" class="form-control" />
  </div>
  <div class="form-group">
    <label for="last-name">Address</label>
    <input type="text" id="address" class="form-control" />
  </div>
  <div class="form-group">
    <label for="last-name">City</label>
    <input type="text" id="city" class="form-control" />
  </div>
  <div class="form-group">
    <label for="last-name">Country</label>
   <select name="country" id="country" class="form-control" required>
                                        <option value="">Select a country</option>
                                        <?php
                                        foreach ($countries as $country) {
                                            echo "<option value=\"$country\">$country</option>";
                                        }
                                        ?>
                                    </select>
  </div>
  <div class="form-group">
    <label for="last-name">Phone</label>
    <input type="tel" id="phone" class="form-control" />
  </div>
  <div class="row mt-5 pt-3 d-flex">
                    <div class="col-md-6 d-flex">
                        <div class="cart-detail cart-total bg-light p-3 p-md-4">
                            <h3 class="billing-heading mb-4">Cart Total</h3>
                            <p class="d-flex">
                                <span>Subtotal</span>
                                <span>N<?php echo number_format($subtotal, 2); ?></span>
                            </p>
                            <p class="d-flex">
                                <span>Delivery</span>
                                <span>N0.00</span>
                            </p>
                            <p class="d-flex">
                                <span>Fee</span>
                                <span>N<?php echo $fee; ?></span> <!-- Adjust as per your discount logic -->
                            </p>
                            <hr>
                            <p class="d-flex total-price">
                                <span>Total</span>
                                <span>N<?php echo number_format($plus, 2); ?></span> <!-- Adjust as per your discount logic -->
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="cart-detail bg-light p-3 p-md-4">
                            <h3 class="billing-heading mb-4">Payment Method</h3>
                            <div class="form-group">
                                <div class="col-md-12">
                                    <div class="radio">
                                        <label><input  type="radio" name="payment_method" class="mr-2" required> Paystack</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <div class="col-md-12">
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="" class="mr-2" required> I have read and accept the terms and conditions</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><br>
  <div class="form-submit">
    <button type="submit" onclick="payWithPaystack()" style="width:100%;" class='btn btn-info'> Pay </button>
  </div>
</form>

<script src="https://js.paystack.co/v1/inline.js"></script> 
<script type="text/javascript">
    const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);
function payWithPaystack(e) {
    var merchantCode = 'pk_live_c9b264686e3aa8c2faa1ee8a5dd766ed323cb145';
  e.preventDefault();

  let handler = PaystackPop.setup({
    key: merchantCode, // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: document.getElementById("amount").value * 100,
    ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
      alert('Window closed.');
    },
    callback: function(response){
      let message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
      let email = document.getElementById("email-address").value;
        let amount = document.getElementById("amount").value;
        let firstName = document.getElementById("first-name").value;
        let lastName = document.getElementById("last-name").value;
        let address = document.getElementById("address").value;
        let city = document.getElementById("city").value;
        let country = document.getElementById("country").value;
        let phone = document.getElementById("phone").value;

    // Create a details string
    let details = `email=${encodeURIComponent(email)}&amount=${encodeURIComponent(amount)}&firstName=${encodeURIComponent(firstName)}&lastName=${encodeURIComponent(lastName)}&address=${encodeURIComponent(address)}&city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&phone=${encodeURIComponent(phone)}`;

      window.location.href = 'success.php?details=' + details;
    }
  });

  handler.openIframe();
}
</script><!-- END -->

            </div> <!-- .col-md-8 -->
        </div>
    </div>
</section> <!-- .section -->





<script src="https://js.paystack.co/v1/inline.js"></script> 
<script type="text/javascript">
    const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);
function payWithPaystack(e) {
    var merchantCode = 'pk_live_c9b264686e3aa8c2faa1ee8a5dd766ed323cb145';
  e.preventDefault();

  let handler = PaystackPop.setup({
    key: merchantCode, // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: document.getElementById("amount").value * 100,
    ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
      alert('Window closed.');
    },
    callback: function(response){
      let message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
    }
  });

  handler.openIframe();
}
</script>
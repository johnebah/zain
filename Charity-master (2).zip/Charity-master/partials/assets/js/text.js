
// $(document).ready(function(){

// $easyButton = $('#simple-button');


// });

function simpleButton(){
	let simple = document.getElementById('simple-text');
	simple.classList.toggle('show-simple-text');
}
function easyButton(){
	let simple = document.getElementById('easy-text');
	simple.classList.toggle('show-easy-text');
}
function hardButton(){
	let simple = document.getElementById('hard-text');
	simple.classList.toggle('show-hard-text');
}


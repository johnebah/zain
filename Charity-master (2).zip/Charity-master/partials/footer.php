
  <script src="partials/js/jquery.min.js"></script>
  <script src="partials/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="partials/js/popper.min.js"></script>
  <script src="partials/js/bootstrap.min.js"></script>
  <script src="partials/js/jquery.easing.1.3.js"></script>
  <script src="partials/js/jquery.waypoints.min.js"></script>
  <script src="partials/js/jquery.stellar.min.js"></script>
  <script src="partials/js/owl.carousel.min.js"></script>
  <script src="partials/js/jquery.magnific-popup.min.js"></script>
  <script src="partials/js/aos.js"></script>
  <script src="partials/js/jquery.animateNumber.min.js"></script>
  <script src="partials/js/bootstrap-datepicker.js"></script>
  <script src="partials/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="partials/js/google-map.js"></script>
  <script src="partials/js/main.js"></script>
    
  </body>
</html>
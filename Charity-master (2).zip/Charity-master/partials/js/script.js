document.addEventListener('DOMContentLoaded', (event) => {
    const quantityInput = document.getElementById('quantity');
    const minusButton = document.querySelector('.quantity-left-minus');
    const plusButton = document.querySelector('.quantity-right-plus');
    
    minusButton.addEventListener('click', () => {
        let currentValue = parseInt(quantityInput.value);
        if (currentValue > parseInt(quantityInput.min)) {
            quantityInput.value = currentValue - 1;
        }
    });
    
    plusButton.addEventListener('click', () => {
        let currentValue = parseInt(quantityInput.value);
        if (currentValue < parseInt(quantityInput.max)) {
            quantityInput.value = currentValue + 1;
        }
    });
});

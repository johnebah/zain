<?php
require "config.php";
require_once 'header.php';
$php = mysqli_query($conn,"SELECT * FROM shop");
$row = mysqli_num_rows($php);
$rows = $row-3;
$php2 = mysqli_query($conn,"SELECT * FROM shop WHERE id > $rows");
?>
    <!-- END nav -->
		
		<section class="ftco-section">
    	<div class="container">
    		<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-12 heading-section text-center ftco-animate">
            <table class="table">
                        <thead class="thead-primary">
                            <tr class="text-center">
                                <th>&nbsp;</th>
                                <th>&nbsp;</th>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $subtotal = 0;
                            if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
                                foreach($_SESSION['cart'] as $key => $item) {
                                    $name = isset($item['name']) ? $item['name'] : 'N/A';
                                    $price = isset($item['price']) ? $item['price'] : 0;
                                    $img = isset($item['img']) ? $item['img'] : 'images/default.png';
                                    $qty = isset($item['qty']) ? $item['qty'] : 1;
                                    $total = $price * $qty;
                                    $subtotal += $total;
                            ?>
                            <tr class="text-center">
                                <td class="product-remove">
                                    <a href="remove_from_cart.php?key=<?php echo $key; ?>" onclick="return confirm('Are you sure you want to remove this item?');">
                                        <span class="ion-ios-close" style="font-size:30px;"></span>
                                    </a>
                                </td>
                                <td class="image-prod">
                                    <div class="img" style="background-image:url('<?php echo $img; ?>');"></div>
                                </td>
                                <td class="product-name">
                                    <h3><?php echo $name; ?></h3>
                                </td>
                                <td class="price">N<?php echo $price; ?></td>
                                <td class="quantity">
                                    <div class="input-group mb-3">
                                        <input type="text" name="quantity" class="quantity form-control input-number" value="<?php echo $qty; ?>" min="1" max="100">
                                    </div>
                                </td>
                                <td class="total">N<?php echo $total; ?></td>
                            </tr>
                            <?php
                                }
                            } else {
                                echo "<tr><td colspan='6' class='text-center'>Your cart is empty.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>

          </div>
           <div class="row justify-content-start">
            <div class="col col-lg-12 col-md-12 mt-5 cart-wrap ftco-animate">
                <div class="cart-total mb-3">
                    <h3>Cart Totals</h3>
                    <p class="d-flex">
                        <span>Subtotal</span>
                        <span>N<?php echo number_format($subtotal, 2); ?></span>
                    </p>
                    <p class="d-flex">
                        <span>Delivery</span>
                        <span>N0.00</span>
                    </p>
                    <p class="d-flex">
                        <span>Discount</span>
                        <span>N0.00</span> <!-- Adjust as per your discount logic -->
                    </p>
                    <hr>
                    <p class="d-flex total-price">
                        <span>Total</span>
                        <span>N<?php echo number_format($subtotal, 2); ?></span> <!-- Adjust as per your discount logic -->
                    </p>
                </div>
                <p class="text-center"><a href="checkout" class="btn btn-primary py-3 px-4">Proceed to Checkout</a></p>
            </div>
        </div>
        </div>
    	</div>
    </section>

    <?php
    require_once "footer.php";
  ?>
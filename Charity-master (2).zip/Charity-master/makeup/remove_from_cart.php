<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_GET['key'])) {
    $key = $_GET['key'];

    // Debugging: Check if key is correctly received
    echo 'Key received: ' . htmlspecialchars($key) . '<br>';

    // Convert key to integer to ensure correct comparison
    $key = (int) $key;

    // Debugging: Output session cart before unsetting
    echo '<pre>Before unset: ';
    var_dump($_SESSION['cart']);
    echo '</pre>';

    // Remove the item from the session cart
    unset($_SESSION['cart'][$key]);

    // Debugging: Output session cart after unsetting
    echo '<pre>After unset: ';
    var_dump($_SESSION['cart']);
    echo '</pre>';

    // Reindex the session cart array numerically
    $_SESSION['cart'] = array_values($_SESSION['cart']);

    // Debugging: Output session cart after reindexing
    echo '<pre>After reindex: ';
    var_dump($_SESSION['cart']);
    echo '</pre>';

    // Optional: Redirect back to the cart page or any other page
    echo "<script>alert('Product removed'); location.href='shop.php';</script>";
    exit;
} else {
    echo 'No key provided';
}
?>

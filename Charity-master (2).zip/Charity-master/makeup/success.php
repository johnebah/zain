<?php
session_start();
require "config.php";
$user = $_GET['details'];
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $cartDetails = ''; // Initialize a variable to hold the concatenated string
    foreach ($_SESSION['cart'] as $key => $item) {
        $name = isset($item['name']) ? $item['name'] : 'N/A';
        $price = isset($item['price']) ? $item['price'] : 0;
        $img = isset($item['img']) ? $item['img'] : 'images/default.png';
        $qty = isset($item['qty']) ? $item['qty'] : 1;
        $des = isset($item['description']) ? $item['description'] : '';
        $total = $price * $qty;
        // $subtotal += $total;

        // Append the product details to the cartDetails string
        $cartDetails .= "Name: $name, Qty: $qty, Description: $des, "; // Assuming description is the same as name, you can change it if there's a separate description field
    }
    $cartDetails = rtrim($cartDetails, ", "); // Remove the trailing comma and space
}
$product = $cartDetails;         
if($user==""){
    header("location:index");
}else{
     $sql1 = mysqli_query($conn,"INSERT INTO orders (user,product)VALUES('$user','$product')");
                     if($sql1){
                         header("location:ender");
                     }
}
?>
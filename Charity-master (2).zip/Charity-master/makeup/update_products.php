<?php
session_start();
$admin = $_SESSION['admin'];
if ($admin == "") {
  header("location:index");
}
// Include database connection
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
  $id = $_POST['id'];
  $name = $_POST['name'];
  $price = $_POST['price'];
  $description = $_POST['description'];
  $category = $_POST['category'];

  // You can also handle image update if needed

  $sql = "UPDATE shop SET name='$name', price='$price', description='$description', category='$category' WHERE id=$id";

  if ($conn->query($sql) === TRUE) {
    echo "Product updated successfully";
    echo "<script>history.back()</script>";
  } else {
    echo "Error updating product: " . $conn->error;
    echo "<script>history.back()</script>";
  }
}

$conn->close();
?>

<?php
session_start();
?>
<form method="post">
	<input type="text" name="txt">
	<input type="submit" name="log">
<?php
if (isset($_POST['log'])) {
	$txt = $_POST['txt'];
	if ($txt == 'xqonishtech') {
		$_SESSION['admin'] = $txt;
		header("location:upload");
	}
}
?>
</form>
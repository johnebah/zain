<?php
require 'config.php';
require_once 'header.php';
$id = $_GET['id'];
$php = mysqli_query($conn,"SELECT * FROM shop WHERE id = '$id' ");
$fetch = mysqli_fetch_assoc($php);
$name = $fetch['name'];
$category = $fetch['category'];
$price = $fetch['price'];
$description = $fetch['description'];
$img = $fetch['img'];
$id = $fetch['id'];
?>
    <!-- END nav -->

    <section class="ftco-section ftco-degree-bg">
      <div class="container">
        <div class="row">
          <div class="col-md-12 ftco-animate">
            <form method="post" action="post">
              <input type="hidden" name="name" value="<?php echo $name; ?>">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="hidden" name="price" value="<?php echo $price; ?>">
                    <input type="hidden" name="description" value="<?php echo $description; ?>">
                    <input type="hidden" name="img" value="<?php echo $img; ?>">
              <center><img src="shop/<?php echo $img; ?>" alt="" class="img-fluid"></center>
            </p>
            <center><h2 class="mb-3"><?php echo $name; ?></h2></center>
            <center><p><?php echo $description; ?></p></center>
            <p>
            
            <center><div class="tag-widget post-tag-container mb-5 mt-5">
              <div class="tagcloud">
                <a href="#" class="tag-cloud-link">PRICE: N<?php echo $price; ?></a>
                <a href="#" class="tag-cloud-link">CATEGORY: Life</a>
              </div>
            </div></center>
            <p>Quantity<input type="number" name="qty" min="1" value="1" class="form-control"></p>
            <p><button class="btn btn-primary btn-lg">Add to Cart</button></p>
            </form>


                

        </div>
      </div>
    </section> <!-- .section -->

    <?php
    require_once "footer.php";
  ?>
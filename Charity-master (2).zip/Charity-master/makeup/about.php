<?php
  require_once "header.php";
?>
    <!-- END nav -->

    <section class="ftco-section">
    	<div class="container">
    		<div class="row d-flex">
    			<div class="col-md-6 d-flex ftco-animate">
    				<div class="img img-about align-self-stretch" style="background-image: url(images/bg_3.jpg); width: 100%;"></div>
    			</div>
    			<div class="col-md-6 pl-md-5 ftco-animate">
    				<h2 class="mb-4">Welcome to Stelwith_Class</h2>
    				<p>TWe have our 9 Foundation Shades from very dark to fair complexion, concealer liquid, blush liquid, highligher liquid, eyeshadow palette, creamy concealer palette, Setting spray, Banana setting powder, Pressed powder, Eyelashes, Contour/blush palette powder, Eyebrow pencil, Face primer, Mascara, Make-up brushes, Lip gloss, Lipstick matte, Eyeliner 2 in 1 glue.</p>
    			</div>
    		</div>
    	</div>
    </section>

    
    <?php
      require_once "footer.php";
    ?>
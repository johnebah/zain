<?php
  require_once "header.php";
?>
<?php
require "config.php";

$php = mysqli_query($conn,"SELECT * FROM shop");
$row = mysqli_num_rows($php);

?>
<style type="text/css">
  .sss {
    display: block;
    width: 300px; /* Set your desired width */
    height: 200px; /* Set your desired height */
    background-size: cover; /* Ensure the image covers the area */
    background-position: center; /* Center the image */
    background-repeat: no-repeat; /* Prevent image repetition */
    border: 1px solid #ddd; /* Optional: add a border for better visibility */
    box-sizing: border-box; /* Include padding and border in the element's total width and height */
}

</style>
    <!-- END nav -->

    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center">
            <h2 class="mb-4">Recent from Shop</h2>
            <p>Shop what you want on Stelwith_Class</p>
          </div>
        </div>
        <div class="row d-flex">
           <?php
            while($fetch = mysqli_fetch_assoc($php)){
              $name = $fetch['name'];
              $category = $fetch['category'];
              $price = $fetch['price'];
              $description = $fetch['description'];
              $img = $fetch['img'];
              $id = $fetch['id'];
              $words = explode(' ', $description);


                if (count($words) > 15) {
                    // Get the first 15 words
                    $words = array_slice($words, 0, 15);
                    
                    // Join the words back into a string
                    $string = implode(' ', $words);
                }

              
            
          ?>
          <div class="col-md-4 d-flex ftco-animate">
          	<div class="blog-entry align-self-stretch">
               <a href="product-single?id=<?php echo $id; ?>" class="block-20 sss" style="background-image: url('shop/<?php echo $img; ?>');">
    </a>
              <div class="text py-4 d-block">
              	<!-- <div class="meta">
                  <div><a href="#">Sept 10, 2018</a></div>
                  <div><a href="#">Admin</a></div>
                  <div><a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a></div>
                </div> -->
                <h3 class="heading mt-2"><a href="#"><?php echo $name; ?></a></h3>
                <p>N<?php echo $price; ?></p>
                <form method="post" action="post">
                    <input type="hidden" name="name" value="<?php echo $name; ?>">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="hidden" name="price" value="<?php echo $price; ?>">
                    <input type="hidden" name="description" value="<?php echo $description; ?>">
                    <input type="hidden" name="img" value="<?php echo $img; ?>">
                    <input type="hidden" name="qty" value="1">
                  
                  <button  type="submit" name="cart" class="btn btn-dark" >Add to cart</button>
                  
                  
                </form>
              </div>
            </div>
          </div>
          <?php
            }
            
          ?>
          
          
        </div>
       
      </div>
    </section>

    <?php
      require_once "footer.php";
    ?>
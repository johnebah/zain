<?php
require_once "header.php";
?>
    <section class="ftco-section contact-section">
        <div class="container mt-5">
          <div class="row block-9">
						<div class="col-md-12 contact-info ftco-animate">
							<div class="row">
								<div class="col-md-12 mb-4">
		              <h2 class="h4">Contact Information</h2>
		            </div>
		            <div class="col-md-12 mb-3">
		              <p><span>Address:</span> Ilorin Kwara State Nigeria OR
Bern, Switzerland CH</p>
		            </div>
		            <div class="col-md-12 mb-3">
		              <p><span>Phone:</span> <a href="tel://1234567920">+234 9050511757 OR +41796378956</a></p>
		            </div>
		            <div class="col-md-12 mb-3">
		              <p><span>Email:</span> <a href="mailto:info@yoursite.com">stelwithclass@gmail.com</a></p>
		            </div>
		            <div class="col-md-12 mb-3">
		              <p><span>Website:</span> <a href="#">stelinitiative.com</a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-0"></div>
            <div class="col-md-0 ftco-animate">
              
            </div>
          </div>
        </div>
      </section>

     
    <?php
    require_once "footer.php"
  ?>
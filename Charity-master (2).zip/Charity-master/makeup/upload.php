
<?php
require 'config.php';
require_once 'header.php';
$admin = $_SESSION['admin'];
if ($admin == "") {
  header("location:index");
}

?>
    <!-- END nav -->

    <div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home</a></span> <span>Cart</span></p>
            <h1 class="mb-0 bread">Upload Product</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section ftco-cart">
			<div class="container">
				<div class="row">
    			<div class="col-md-12 ftco-animate">
    				<form action="insert_product.php" method="post" enctype="multipart/form-data">
				        <label for="name">Product Name:</label>
				        <input type="text" id="name" name="name" required><br><br>

				        <label for="price">Price:</label>
				        <input type="number" id="price" name="price" required><br><br>

				        <label for="description">Description:</label>
				        <textarea id="description" name="description" required></textarea><br><br>

				        <label for="category">Category:</label>
				        
				        <select name="category" required>
				        	<option>Camera</option>
				        	<option>DVR Channel</option>
				        	<option>Switch Box</option>
				        </select>
				        <br><br>

				        <label for="image">Image:</label>
				        <input type="file" id="image" name="image" required><br><br>

				        <input type="submit" value="Add Product">
    				</form>
    			</div>
    		</div>
			</div>
			<table class="table table-striped">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Price</th>
                  <th>Description</th>
                  <th>Category</th>
                  <th>Image</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php
                // Include database connection
                

                $sql = "SELECT id, name, price, description, category, img FROM shop";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                  while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['name']}</td>
                            <td>{$row['price']}</td>
                            <td>{$row['description']}</td>
                            <td>{$row['category']}</td>
                            <td><img src='shop/{$row['img']}' alt='{$row['name']}' style='width: 100px; height: auto;'></td>
                            <td>
                              <form action='update_product.php' method='post' style='display:inline-block;'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <input type='submit' value='Update'>
                              </form>
                              <form action='delete_product.php' method='post' style='display:inline-block;'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <input type='submit' value='Delete' onclick='return confirm(\"Are you sure?\")'>
                              </form>
                            </td>
                          </tr>";
                  }
                } else {
                  echo "<tr><td colspan='6'>No products uploaded yet</td></tr>";
                }

                $conn->close();
                ?>
              </tbody>
            </table>
		</section>
		
		

    <?php
require_once 'footer.php';
?>
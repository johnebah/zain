<?php

require_once 'header.php';

// Function to calculate the subtotal
function calculateSubtotal($cart) {
    $subtotal = 0;
    foreach($cart as $item) {
        $subtotal += $item['price'] * $item['qty'];
    }
    return $subtotal;
}



$subtotal = isset($_SESSION['cart']) ? calculateSubtotal($_SESSION['cart']) : 0;
$fee = (1/100)*$subtotal;
$plus = $fee + $subtotal;

// List of all countries
$countries = [
    "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", 
    "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", 
    "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", 
    "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic", "Chad", 
    "Chile", "China", "Colombia", "Comoros", "Congo, Democratic Republic of the", "Congo, Republic of the", 
    "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", 
    "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", 
    "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada", 
    "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary", "Iceland", "India", 
    "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", 
    "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", 
    "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", 
    "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", 
    "Monaco", "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", 
    "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Macedonia", "Norway", "Oman", "Pakistan", "Palau", 
    "Palestine", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", 
    "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", 
    "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", 
    "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "Spain", "Sri Lanka", 
    "Sudan", "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", 
    "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", 
    "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", 
    "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"
];

?>
<!-- END nav -->

<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
    <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
                <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home</a></span> <span>Checkout</span></p>
                <h1 class="mb-0 bread">Checkout</h1>
            </div>
        </div>
    </div>
</div>

<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-10 ftco-animate">
                <form id="paymentForm">
  <div class="form-group">
    <label for="email">Email Address</label>
    <input type="email" id="email-address" required class="form-control" />
  </div>
  <!-- <div class="form-group"> -->
    <!-- <label for="amount">Amount</label> -->
    <input type="hidden" id="amount" required class="form-control" value="<?php echo $plus; ?>" />
  <!-- </div> -->
  <div class="form-group">
    <label for="first-name">First Name</label>
    <input type="text" id="first-name" class="form-control" />
  </div>
  <div class="form-group">
    <label for="last-name">Last Name</label>
    <input type="text" id="last-name" class="form-control" />
  </div>
  <div class="form-group">
    <label for="last-name">Address</label>
    <input type="text" id="address" class="form-control" />
  </div>
  <div class="form-group">
    <label for="last-name">City</label>
    <input type="text" id="city" class="form-control" />
  </div>
  <div class="form-group">
    <label for="last-name">Country</label>
   <select name="country" id="country" class="form-control" required>
                                        <option value="">Select a country</option>
                                        <?php
                                        foreach ($countries as $country) {
                                            echo "<option value=\"$country\">$country</option>";
                                        }
                                        ?>
                                    </select>
  </div>
  <div class="form-group">
    <label for="last-name">Phone</label>
    <input type="tel" id="phone" class="form-control" />
  </div>
  <div class="row mt-5 pt-3 d-flex">
                    <div class="col-md-6 d-flex">
                        <div class="cart-detail cart-total bg-light p-3 p-md-4">
                            <h3 class="billing-heading mb-4">Cart Total</h3>
                            <p class="d-flex">
                                <span>Subtotal</span>
                                <span>N<?php echo number_format($subtotal, 2); ?></span>
                            </p>
                            <p class="d-flex">
                                <span>Delivery</span>
                                <span>N0.00</span>
                            </p>
                            <p class="d-flex">
                                <span>Fee</span>
                                <span>N<?php echo $fee; ?></span> <!-- Adjust as per your discount logic -->
                            </p>
                            <hr>
                            <p class="d-flex total-price">
                                <span>Total</span>
                                <span>N<?php echo number_format($plus, 2); ?></span> <!-- Adjust as per your discount logic -->
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="cart-detail bg-light p-3 p-md-4">
                            <h3 class="billing-heading mb-4">Payment Method</h3>
                            <div class="form-group">
                                <div class="col-md-12">
                                    <div class="radio">
                                        <label><input  type="radio" name="payment_method" class="mr-2" required> Paystack</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <div class="col-md-12">
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="" class="mr-2" required> I have read and accept the terms and conditions</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><br>
  <div class="form-submit">
    <button type="submit" onclick="payWithPaystack()" style="width:100%;" class='btn btn-info'> Pay </button>
  </div>
</form>

<script src="https://js.paystack.co/v1/inline.js"></script> 
<script type="text/javascript">
    const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);
function payWithPaystack(e) {
    var merchantCode = 'pk_live_c9b264686e3aa8c2faa1ee8a5dd766ed323cb145';
  e.preventDefault();

  let handler = PaystackPop.setup({
    key: merchantCode, // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: document.getElementById("amount").value * 100,
    ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
      alert('Window closed.');
    },
    callback: function(response){
      let message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
      let email = document.getElementById("email-address").value;
        let amount = document.getElementById("amount").value;
        let firstName = document.getElementById("first-name").value;
        let lastName = document.getElementById("last-name").value;
        let address = document.getElementById("address").value;
        let city = document.getElementById("city").value;
        let country = document.getElementById("country").value;
        let phone = document.getElementById("phone").value;

    // Create a details string
    let details = `email=${encodeURIComponent(email)}&amount=${encodeURIComponent(amount)}&firstName=${encodeURIComponent(firstName)}&lastName=${encodeURIComponent(lastName)}&address=${encodeURIComponent(address)}&city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&phone=${encodeURIComponent(phone)}`;

      window.location.href = 'success.php?details=' + details;
    }
  });

  handler.openIframe();
}
</script><!-- END -->

            </div> <!-- .col-md-8 -->
        </div>
    </div>
</section> <!-- .section -->

<?php
require_once 'footer.php';
?>



<script src="https://js.paystack.co/v1/inline.js"></script> 
<script type="text/javascript">
    const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);
function payWithPaystack(e) {
    var merchantCode = 'pk_live_c9b264686e3aa8c2faa1ee8a5dd766ed323cb145';
  e.preventDefault();

  let handler = PaystackPop.setup({
    key: merchantCode, // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: document.getElementById("amount").value * 100,
    ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
      alert('Window closed.');
    },
    callback: function(response){
      let message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
    }
  });

  handler.openIframe();
}
</script>
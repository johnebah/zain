<?php
session_start();

if (isset($_POST['cart'])) {
    if (isset($_SESSION['cart'])) {
        $item_id = array_column($_SESSION['cart'], "id");
        if (in_array($_POST['id'], $item_id)) {
            foreach ($_SESSION['cart'] as $key => $value) {
                if ($_SESSION['cart'][$key]['id'] == $_POST['id']) {
                    $_SESSION['cart'][$key]["qty"] += $_POST['qty'];
                    echo "<script>alert('Product already in cart, quantity added'); history.back();</script>";
                    exit;
                }
            }
        } else {
            $count = count($_SESSION['cart']);
            $item = array(
                "name" => $_POST['name'],
                "id" => $_POST['id'],
                "description" => $_POST['description'],
                "price" => $_POST['price'],
                "img" => $_POST['img'],
                "qty" => $_POST['qty']
            );

            $_SESSION['cart'][$count] = $item;
            echo "<script>alert('Added to cart'); history.back();</script>";
            exit;
        }
    } else {
        $item = array(
            "name" => $_POST['name'],
            "id" => $_POST['id'],
            "description" => $_POST['description'],
            "price" => $_POST['price'],
            "img" => $_POST['img'],
            "qty" => $_POST['qty']
        );

        $_SESSION['cart'][0] = $item;
        echo "<script>alert('Added to cart'); history.back();</script>";
        exit;
    }
}
?>

<?php
session_start();
$admin = $_SESSION['admin'];
if ($admin == "") {
  header("location:index");
}
// Include database connection
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
  $id = $_POST['id'];

  $sql = "DELETE FROM products WHERE id=$id";

  if ($conn->query($sql) === TRUE) {
    echo "Product deleted successfully";
    echo "<script>history.back();</script>";
  } else {
    echo "Error deleting product: " . $conn->error;
    echo "<script>history.back();</script>";
  }
}

$conn->close();
?>

<!-- home.php -->
<h1>Welcome to the Home Page</h1>
<p>This is the homepage content.</p>

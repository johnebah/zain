<?php
require_once "header.php";
?>

	<!-- Home -->

	

	<!-- Blog -->

	<div class="blog">
		<div class="container">
			<div class="row">
				
				<!-- Blog Posts -->
				<div class="col-lg-12">
					<div class="blog_posts">
						
						<!-- Blog Post -->
						<div class="blog_post">
							
							<div class="blog_post_image"><img style="width: 100%;" src="images/fire.jpg"></div><br>
							<div class="blog_post_title"><h2>Bobby The Gambit</h2></div>
							
							<div class="blog_post_text">
								<p><i>Fire</i><br>

Chiezey Chukwueloka popularly known as Bobby The Gambit, born on May 18th in Enugu state hails from Igbariam in Anambra State, Nigeria. 
 He is a vibrant music enthusiast with a deep passion for good sounds and song composition. 
He honed his musical skills in school bands and choir, mastering instruments like drums, flute, and konga. 
Bobby artistically blends Afrobeat(s) and Hip-Hop styles in his music with the intention to bridge musical/cultural gaps. He actively engages with the entertainment industry to build connections and a supportive community for his music.</p>
							</div>
						</div>

						<!-- Blog Post -->
						

						
				<!-- Sidebar -->
				

			</div>
		</div>
	</div>

	<!-- Footer -->

	<?php
		require_once "footer.php";
	?>
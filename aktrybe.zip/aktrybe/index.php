<?php
		require_once "header.php";
	?>
<style type="text/css">
	.background_image {
    background-size: cover; /* Ensure the image covers the entire container */
    background-position: center; /* Center the image within the container */
    background-repeat: no-repeat; /* Prevent the image from repeating */
    width: 100%; /* Ensure the container takes full width */
    height: 100%; /* Ensure the container takes full height */
}


</style>

	<!-- Home -->
<br><br>
	<div class="home">
		<div class="home_slider_container">
			
			<!-- Home Slider -->
			<div class="owl-carousel owl-theme home_slider">
				
				<!-- Slide -->
				<div class="owl-item">
					<div class="background_image" style="background-image:url(images/water.jpg)"></div>
					<div class="home_container">
						<div class="home_container_inner d-flex flex-column align-items-center justify-content-center">
							<div class="home_content text-center">
								<div class="home_subtitle">Aktv Tryb3</div>
								<div class="home_title"><h1>Fortune Lio C</h1></div>
								<div class="home_link"><a href="#">Listen on Spotify</a></div>
							</div>
						</div>
					</div>
				</div>

				<!-- Slide -->
				<div class="owl-item">
				    <div class="background_image" style="background-image:url(images/wind.jpg)"></div>
				    <div class="home_container">
				        <div class="home_container_inner d-flex flex-column align-items-center justify-content-center">
				            <div class="home_content text-center">
				                <div class="home_subtitle">Aktv Tryb3</div>
				                <div class="home_title"><h1>KHiiD</h1></div>
				                <div class="home_link"><a href="#">Listen on Spotify</a></div>
				            </div>
				        </div>
				    </div>
				</div>

				<!-- Slide -->
				<div class="owl-item">
				    <div class="background_image" style="background-image:url(images/air.jpg)"></div>
				    <div class="home_container">
				        <div class="home_container_inner d-flex flex-column align-items-center justify-content-center">
				            <div class="home_content text-center">
				                <div class="home_subtitle">Aktv Tryb3</div>
				                <div class="home_title"><h1>Astro</h1></div>
				                <div class="home_link"><a href="#">Listen on Spotify</a></div>
				            </div>
				        </div>
				    </div>
				</div>


				<!-- Slide -->
				<div class="owl-item">
					<div class="background_image" style="background-image:url(images/fire.jpg)"></div>
					<div class="home_container">
						<div class="home_container_inner d-flex flex-column align-items-center justify-content-center">
							<div class="home_content text-center">
								<div class="home_subtitle">Aktv Tryb3</div>
								<div class="home_title"><h1>Bobby The Gambit</h1></div>
								<div class="home_link"><a href="#">Listen on Spotify</a></div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Featured Album -->

	<!-- <div class="featured_album">
		<div class="background_image featured_background" style="background-image:url(images/featured.png)"></div>
		
	</div> -->

	<!-- Shows -->

	

	<!-- Artist -->

	<!-- Extra -->

	
	<!-- Footer -->

	<?php
		require_once "footer.php";
	?>
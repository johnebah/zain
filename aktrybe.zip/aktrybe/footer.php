<br><br><div class="row">
				<div class="col-md-12">
					<center>
						<a href="https://www.instagram.com/aktvtryb3_?igsh=MXczN3N5YzVmY25ybg=="><i class="fa fa-instagram" aria-hidden="true" style="color:white;font-size: 40px;"></i></a>
						<a href="#"><i class="fa fa-facebook" aria-hidden="true" style="color:white;font-size: 40px;padding: 3px;"></i></a>
						<a href="#"><i class="fa fa-twitter" aria-hidden="true" style="color:white;padding: 3px;font-size: 40px;"></i></a>
						
						
					</center>
				</div>
			</div>

<footer class="footer">
		<div class="footer_container d-flex flex-xl-row flex-column align-items-start justify-content-start">

			
   




				<!-- Mixtape -->
				
			</div>
		</div>
		<center>
	</ul>
	</div>

			<div class="copyright_bar">
			<span style="text-align: center;"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Aktv Tryb3 <i class="fa fa-heart-o" aria-hidden="true"></i>  <a href="https://www.instagram.com/john_ebah" target="_blank">Designed by Jcode Tech Center</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</span>
		</div></center>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/progressbar/progressbar.min.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/jPlayer/jquery.jplayer.min.js"></script>
<script src="plugins/jPlayer/jplayer.playlist.min.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
  $(".home_slider").owlCarousel({
    items: 1, // Number of items per slide
    loop: true, // Loop through the items
    autoplay: true, // Enable auto-play
    autoplayTimeout: 5000, // 5000ms = 5 seconds
    autoplayHoverPause: true, // Pause on hover
    nav: true, // Show navigation buttons
    dots: true, // Show pagination dots
  });
});

</script>
</body>
</html>
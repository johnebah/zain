<?php
require_once "header.php";
?>

	<!-- Home -->

	

	<!-- Blog -->

	<div class="blog">
		<div class="container">
			<div class="row">
				
				<!-- Blog Posts -->
				<div class="col-lg-12">
					<div class="blog_posts">
						
						<!-- Blog Post -->
						<div class="blog_post">
							
							<div class="blog_post_image"><img style="width: 100%;" src="images/water.jpg"></div><br>
							<div class="blog_post_title"><h2>Fortune Lio C</h2></div>
							
							<div class="blog_post_text">
								<p><i>Water</i><br>


Eweh Job Fortune professionally known as FORTUNE LIO C, is a musician born on April 21 in Benue State,Nigeria. His musical journey began in 2015 as a teenager and evolved into a full-fledged career by 2018. His story exemplifies the power of determination and hard work, serving as an inspiration to aspiring artists around the world.</p>
							</div>
						</div>

						<!-- Blog Post -->
						

						
				<!-- Sidebar -->
				

			</div>
		</div>
	</div>

	<!-- Footer -->

	<?php
		require_once "footer.php";
	?>
<?php
		require_once "header.php";
	?>
	<!-- Home -->

	

	<!-- Discs -->

<style type="text/css">
	.artist_image_container {
  background-image: url('images/element.jpg');
  background-size: contain; /* Use 'contain' to ensure the whole image fits within the container */
  background-position: center;
  background-repeat: no-repeat;
  width: 100%;
  height: 300px; /* Set a specific height for the container */
}

@media (max-width: 768px) {
  .artist_image_container {
    height: 200px; /* Adjust height for mobile view if needed */
  }
}


</style>
	<!-- Artist -->

	<div class="container">
  <div class="row">
    
    <div class="col-12 col-lg-12">
      <div class="artist_content">
        <div class="section_title_container">
          <div class="section_subtitle">ELEM3NTA1S</div>
          <div class="section_title"><h1>About Us</h1></div>
        </div>
        <div class="artist_text">
          <p>ELEM3NTA1S, the Afrobeat powerhouse signed under AKTV TRYB3, stands as a seasoned and revered music ensemble. With a lineup of four exceptional artists, their music transcends borders, infusing traditional Afrobeat rhythms with a contemporary twist. </p>
          <p>ELEM3NTA1S established presence in the music scene is a testament to their artistry and ability to captivate audiences with their infectious tunes. Join the musical journey with ELEM3NTA1S and immerse yourself in the vibrant sounds of their well-established band.</p>
        </div>
      </div>
    </div>
  </div>
</div>


	<!-- Footer -->

	<?php
		require_once "footer.php";
	?>
<?php

require_once "header.php";
?>
<link rel="stylesheet" type="text/css" href="styles/bootstrap-4.1.2/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/contact.css">
<link rel="stylesheet" type="text/css" href="styles/contact_responsive.css">
	<!-- Home -->

	

	<!-- Contact -->
<br><br>
	<div class="contact">
		<div class="container">
			<div class="row">
				
					<div class="col-md-6"><center style="padding: 30px;">
								<i class="fa fa-phone" style="font-size: 60px; color:orange;background: brown;border-radius: 50%; padding: 15px;"></i><p style="color:grey;">Call us today</p><p>+1 (718) 812-4552</p></center>
					</div>
						<div class="col-md-6">
								<center style="padding: 30px;"><i class="fa fa-envelope" style="font-size: 60px; color:orange;background: brown;border-radius: 50%; padding: 15px;"></i><p style="color:grey;">Send an Email</p><p>Aktvtryb3@gmail.com</p></center>
					</div>
				
							
						</div>
			<div class="row">
				
				<!-- Contact Form -->
				<div class="col-lg-6">
					<div class="contact_form_container">
						
						<div class="contact_title">Contact us</div>
						<p>Our team will be in touch with you soon</p>
						<form action="#" class="contact_form" id="contact_form">
							<input type="text" class="contact_input" placeholder="Name" required="required">
							<input type="email" class="contact_input" placeholder="E-mail" required="required">
							<input type="text" class="contact_input" placeholder="Subject">
							<textarea class="contact_input contact_textarea" placeholder="Message" required="required"></textarea>
							<button class="contact_button">Send Message</button>
						</form>
					</div>
				</div>

				<!-- Contact Info -->
				<div class="col-lg-6 contact_col">
					<div class="contact_info">
						<div class="contact_title">Where to reach out to us</div>
						
						<div class="contact_info_list">
							<ul>
								
								<li class="d-flex flex-row align-items-start justify-content-start">
									<div><div>Phone</div></div>
									<div>+1 (718) 812-4552</div>
								</li>
								<li class="d-flex flex-row align-items-start justify-content-start">
									<div><div>E-mail</div></div>
									<div>Aktvtryb3@gmail.com</div>
								</li>
							</ul>
						</div>
						<div class="social">
							<ul class="d-flex flex-row align-items-center justify-content-start">
								<li><a href="https://www.instagram.com/aktvtryb3_?igsh=MXczN3N5YzVmY25ybg=="><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->

	<?php
	require_once "footer.php";
?>
<?php
require_once "header.php";
?>

	<!-- Home -->

	

	<!-- Blog -->

	<div class="blog">
		<div class="container">
			<div class="row">
				
				<!-- Blog Posts -->
				<div class="col-lg-12">
					<div class="blog_posts">
						
						<!-- Blog Post -->
						<div class="blog_post">
							
							<div class="blog_post_image"><img style="width: 100%;" src="images/wind.jpg"></div><br>
							<div class="blog_post_title"><h2>KHiiD</h2></div>
							
							<div class="blog_post_text">
								<p><i>Air</i><br>


KHiiD, whose real name is Oluwasetemi Success Falade, is a Nigerian singer and songwriter born on the 17th of May. He hails from Ekiti state but was raised in Akure, Ondo state. He began singing as a child in the church choir because he accompanied his mother to choir rehearsals, which sparked his interest in music.

The Afrobeats artist has released several songs, including a collaboration with Fortune LIO C. He draws inspiration from his surroundings, his mother, and his emotions. This rising star, who aspires to collaborate with artists like Tems, Oxlade, and Rema, enjoys playing musical instruments in his leisure time.</p>
							</div>
						</div>

						<!-- Blog Post -->
						

						
				<!-- Sidebar -->
				

			</div>
		</div>
	</div>

	<!-- Footer -->

	<?php
		require_once "footer.php";
	?>
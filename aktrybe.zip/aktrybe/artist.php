<?php
require_once "header.php";
?>
<style type="text/css">
	.card{
		margin: 10px;
	}
	.card p{
		color: black;
	}
	.card p:hover{
		color: white;
	}
	.card:hover{
		background-color: orange;
		color:white;
		transition: 0.5s ease all;
	}
</style>
	<!-- Home -->

	<!--  -->

	<!-- Blog -->

	<div class="blog">
		<div class="container">
			<div class="row">
				
				<!-- Blog Posts -->
				<div class="col-lg-12">
					
						<div class="blog_post_image"><img src="images/elem.png" style="width:100%;"></div>
				</div>
				<div class="col-lg-12">
					
						 <div class="artist_text" style="padding:10px;">
          <p>ELEM3NTA1S, the Afrobeat powerhouse signed under AKTV TRYB3, stands as a seasoned and revered music ensemble. With a lineup of four exceptional artists, their music transcends borders, infusing traditional Afrobeat rhythms with a contemporary twist. </p>
          <p>ELEM3NTA1S established presence in the music scene is a testament to their artistry and ability to captivate audiences with their infectious tunes. Join the musical journey with ELEM3NTA1S and immerse yourself in the vibrant sounds of their well-established band.</p>
        </div>
				</div>
						<!-- Blog Post -->
						

			</div>
		</div><br><br>
<center>

		<div class="container">
			<div class="row">
				
				<!-- Blog Posts -->
				<div class="col-md-3">
					
					<div class="card" style="height:100px; width:100px;">
						<p style="text-align: center;margin: auto;font-weight: bolder;">EARTH</p><p style="text-align: center;margin: auto;font-weight: bolder;"><a href="single3" class="btn btn-warning">Read Bio</a></p>
					</div>	
				</div>
				<div class="col-md-3">
					
					<div class="card" style="height:100px; width:100px;"><p style="text-align: center;margin: auto;font-weight: bolder;">WIND</p><p style="text-align: center;margin: auto;font-weight: bolder;"><a href="single2" class="btn btn-warning">Read Bio</a></p></div>	
				</div>
				<div class="col-md-3">
					
					<div class="card" style="height:100px; width:100px;"><p style="text-align: center;margin: auto;font-weight: bolder;">WATER</p><p style="text-align: center;margin: auto;font-weight: bolder;"><a href="single" class="btn btn-warning">Read Bio</a></p></div>	
				</div>
				<div class="col-md-3">
					<div class="card" style="height:100px; width:100px;"><p style="text-align: center;margin: auto;font-weight: bolder;">FIRE</p><p style="text-align: center;margin: auto;font-weight: bolder;"><a href="single4" class="btn btn-warning">Read Bio</a></p></div>
						
				</div>
						<!-- Blog Post -->
						

			</div>
		</div>
	</div>
</center>
	<!-- Footer -->

	<?php
require_once "footer.php";
?>
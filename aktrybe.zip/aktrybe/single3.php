<?php
require_once "header.php";
?>

	<!-- Home -->

	

	<!-- Blog -->

	<div class="blog">
		<div class="container">
			<div class="row">
				
				<!-- Blog Posts -->
				<div class="col-lg-12">
					<div class="blog_posts">
						
						<!-- Blog Post -->
						<div class="blog_post">
							
							<div class="blog_post_image"><img style="width: 100%;" src="images/air.jpg"></div><br>
							<div class="blog_post_title"><h2>Astro</h2></div>
							
							<div class="blog_post_text">
								<p><i>Earth</i><br>

Stephanie Onyemowo Moses, popularly known as ASTRO, is a talented musician with a deep passion for music. Her musical journey began in the church choir, where she honed her skills and discovered her love for music.

As she matured, her musical talents flourished, and she started to explore various sounds and styles that resonated with her unique artistic vision. At the young age of 15, she picked up the guitar, and by 17, she was captivating audiences at different events with her performances.

ASTRO's soulful voice and captivating stage presence never fail to mesmerize her listeners. Her music not only entertains but also touches the hearts of those who hear it. Stephanie is a true artist, pouring her passion and creativity into every melody she creates, leaving a lasting impact on her fans worldwide.</p>
							</div>
						</div>

						<!-- Blog Post -->
						

						
				<!-- Sidebar -->
				

			</div>
		</div>
	</div>

	<!-- Footer -->

	<?php
		require_once "footer.php";
	?>
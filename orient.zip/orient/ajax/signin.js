var form = document.querySelector("form");
var allfields = document.querySelector("#allfields");

var Register = document.querySelector("#Register");
Register.addEventListener("click", Reg);
function Reg() {
	let xhr = new XMLHttpRequest;

	xhr.open("POST","php/signin.php");

	xhr.onload = () =>{
		if (xhr.readyState == XMLHttpRequest.DONE) {
			if (xhr.status == 200) {
				let response = xhr.response;
				if (response=="success") {
					window.location.href = 'admin/index';
				}else{
					allfields.textContent = response;
					allfields.scrollIntoView();
				}
			}
		}
	}
	let formData = new FormData(form);
	xhr.send(formData)
}


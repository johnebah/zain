<?php
	$con = mysqli_connect("localhost","root","","orient");
	if(!$con){
		echo "No database Found";
	}
?>
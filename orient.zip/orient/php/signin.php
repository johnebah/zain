<?php
session_start();

require "config.php";


$email = mysqli_real_escape_string($con,$_POST['email']);
$password = mysqli_real_escape_string($con,$_POST['pword']);

    if(!empty($email) && !empty($password)){
        $sql = mysqli_query($con,"SELECT * FROM members WHERE email='$email' OR id='$email' ");
        if(mysqli_num_rows($sql)>0){
            $fetch = mysqli_fetch_assoc($sql);
            $data = $fetch['email'];
            $pass = $fetch['password'];
            if($pass == $password){
            $_SESSION['user'] = $email;
             echo "success";
            }else{
                echo "Invalid Password";
            }  
        }else{
            echo "No User with that ID or Email found";
        }
    }else{
        echo "Please input all fields";
    }
?>
<?php
require "config.php";
session_start();


$name = mysqli_real_escape_string($con,$_POST['fname']);
$phone = mysqli_real_escape_string($con,$_POST['mobile']);
$email = mysqli_real_escape_string($con,$_POST['email']);
$course = mysqli_real_escape_string($con,$_POST['course']);
$coupon = mysqli_real_escape_string($con,$_POST['coupon']);
$password = mysqli_real_escape_string($con,$_POST['pword']);
$cpassword = mysqli_real_escape_string($con,$_POST['cpword']);

$caller = mysqli_query($con,"SELECT * FROM members WHERE email = '$email' ");
if(mysqli_num_rows($caller)>0){
    echo "User With this email already exist";
}else{
    if(!empty($name) && !empty($phone) && !empty($email) && !empty($course) && !empty($coupon) && !empty($password)){
        if(filter_var($email,FILTER_VALIDATE_EMAIL)){
            if(strlen($password)>7){
                if($password==$cpassword){
                    $available_coupon = mysqli_query($con,"SELECT * FROM coupon WHERE code = '$coupon' ");
                    if(mysqli_num_rows($available_coupon)>0){
                        $identity = rand(time(),100000);
                        $reg = mysqli_query($con,"INSERT INTO members(id,name,phone,email,course,password)
                        VALUES('$identity','$name','$phone','$email','$course','$password') ");
                        if($reg){
                            $del = mysqli_query($con,"DELETE FROM coupon WHERE code = '$coupon' ");
                            if($del){
                                $_SESSION['user'] = $email;
                                echo "success";
                            }else{
                                echo "Oops something went wrong";
                            }
                        }else{
                            echo "Oops something went wrong, please try again";
                        }
                    }else{
                        echo "Invalid Coupon code";
                    }
                }else{
                    echo "Password does not match";
                }
            }else{
                echo "Password length too short";
            }
        }else{
            echo "Invalid email address";
        }
    }else{
        echo "Please input all fields";
    }
}
?>
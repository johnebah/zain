<?php
require 'config.php';

if (isset($_POST['track'])) {
    $tracking_num = $_POST['number'];
    $sql = mysqli_query($con, "SELECT * FROM orders WHERE tracking = '$tracking_num'");
    if (mysqli_num_rows($sql) > 0) {
        $fetch = mysqli_fetch_assoc($sql);
        $name = $fetch['name'];
        $progress = $fetch['progress'];
        $details = [
            ['detail' => $fetch['detail1'], 'label' => $fetch['label1'], 'progress' => 25],
            ['detail' => $fetch['detail2'], 'label' => $fetch['label2'], 'progress' => 50],
            ['detail' => $fetch['detail3'], 'label' => $fetch['label3'], 'progress' => 75],
            ['detail' => $fetch['detail4'], 'label' => $fetch['label4'], 'progress' => 100],
        ];
        $info = $fetch['information'];
    } else {
        echo "<script>
            alert('Invalid Tracking Number');
            window.location.href = 'index';
        </script>";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <title>DHL &mdash; Track your orders</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="Free-Template.co" />
    <link rel="shortcut icon" href="dhl.png">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,700|Oswald:400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300" style="overflow-x:hidden;">

<div id="overlayer"></div>
<div class="loader">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>

<div class="site-wrap" id="home-section">
    <header class="site-navbar js-sticky-header site-navbar-target" role="banner">
        <div class="container">
            <div class="row align-items-center position-relative">
                <div class="site-logo">
                    <a href="index" class="text-black"><span class="text-primary">=<span style="font-style: italic;">DHL</span>=</a>
                </div>
                <div class="col-12">
                    <nav class="site-navigation text-right ml-auto " role="navigation">
                        <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
                            <li><a href="index" class="nav-link">Home</a></li>
                            <li><a href="tracking" class="nav-link">Tracking</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="toggle-button d-inline-block d-lg-none"><a href="#" class="site-menu-toggle py-5 js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <br>
                <h2 style="text-align:center;"><?php echo $name; ?></h2><br><br><br>
                <progress min="0" max="100" value="<?php echo $progress; ?>" style="width:100%;background: whitesmoke;border-radius: 20px;" class="form-control"></progress><br><br>
            </div>
        </div>
        <div class="row">
            <?php foreach ($details as $detail) { ?>
                  <div class="col-md-3 text-center">
                      <div class="circle" style="width:50px;height: 50px;background-color: <?php echo ($progress >= $detail['progress']) ? 'green' : 'red'; ?>;border-radius: 50%; padding: 10px; margin: 0 auto;">
                          <?php if ($progress >= $detail['progress']) { ?>
                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" style="width: 24px; height: 24px;"><path fill="white" d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"/></svg>
                          <?php } else { ?>
                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" style="width: 24px; height: 24px;"><path fill="white" d="M231.6 256L374.6 113c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 54.63 73.37c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L152.4 256 9.373 399c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3l137.4 137.4c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L231.6 256z"/></svg>
                          <?php } ?>
                      </div>
                      <h4><?php echo $detail['detail']; ?></h4>
                      <p><?php echo $detail['label']; ?></p>
                  </div>
              <?php } ?>

        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12"><br><br>
                <div class="order-information" style="background: grey; border-radius: 20px;padding: 20px;color:white;">
                    <h4 style="text-align: center;">ORDER INFORMATION</h4>
                    <p style="text-align:center;"><?php echo $info; ?></p>
                </div><br><br>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-7">
                            <h2 class="footer-heading mb-4">About Us</h2>
                            <p>Discover how DHL’s global reach and local knowledge can help move your pallets, containers and other cargo across Europe or around the world.</p>
                        </div>
                        <div class="col-md-4 ml-auto">
                            <h2 class="footer-heading mb-4">Features</h2>
                            <ul class="list-unstyled">
                                <li><a href="#">About Us</a></li>
                                <li><a href="tracking">Tracking</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 ml-auto">
                    <div class="mb-5">
                        <h2 class="footer-heading mb-4">Subscribe to Newsletter</h2>
                        <form action="#" method="post" class="footer-suscribe-form">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                                <div class="input-group-append">
                                    <button class="btn btn-primary text-white" type="button" id="button-addon2">Subscribe</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- <h2 class="footer-heading mb-4">Follow Us</h2>
                    <a href="#" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                    <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                    <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                    <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a> -->
                </div>
            </div>
            <div class="row pt-5 mt-5 text-center">
                <div class="col-md-12">
                    <div class="border-top pt-5">
                       <!--  <p class="copyright">
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://free-template.co" target="_blank">Free-Template.co</a>
                        </p> -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>

<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.countdown.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/main.js"></script>
</body>
</html>

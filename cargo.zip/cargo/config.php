<?php
	$con = mysqli_connect("localhost","root","","cargo");
	if(!$con){
		echo "No database found";
	}
?>